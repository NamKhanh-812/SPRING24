package com.example.lab1_ph43678;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class bai3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bai3);
    }
}