package com.example.lab2_ph43678;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Bai1 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bai1);
    }
}