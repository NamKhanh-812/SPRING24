package com.example.assignment_gd1.model;

public class phongban {
    private String tenPhongBan;

    public phongban() {
    }

    public phongban(String tenPhongBan) {
        this.tenPhongBan = tenPhongBan;
    }

    public String getTenPhongBan() {
        return tenPhongBan;
    }

    public void setTenPhongBan(String tenPhongBan) {
        this.tenPhongBan = tenPhongBan;
    }
}
