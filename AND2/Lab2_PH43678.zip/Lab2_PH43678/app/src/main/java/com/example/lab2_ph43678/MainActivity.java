package com.example.lab2_ph43678;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.lab2_ph43678.adapter.cvAdapter;
import com.example.lab2_ph43678.dao.CongViecDao;
import com.example.lab2_ph43678.model.CongViec;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView rcvCongViec;
    FloatingActionButton fltAdd;
    CongViecDao congViecDao;
    cvAdapter adapter;
    private ArrayList<CongViec> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rcvCongViec = findViewById(R.id.rcvCongViec);
        fltAdd = findViewById(R.id.fltAdd);
        // lấy toàn bộ dữ liệu từ bảng cng việc , add dữ liệu vào list
        congViecDao = new CongViecDao(this);
        list = congViecDao.selectAll();
        //set layout cho recylerView
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        rcvCongViec.setLayoutManager(layoutManager);
        //đổ lữ liệu lên recylerView
        adapter = new cvAdapter(this, list);
        rcvCongViec.setAdapter(adapter);
        //xử lý nút add
        fltAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opendialogThem();
            }
        });
    }
    public void opendialogThem(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        // gắn layout
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.item_add,null);
        builder.setView(view); //gắn view vào hộp thoại
        Dialog dialog = builder.create(); // tạo dialog
        dialog.show();
        // ánh xạ các thành phần
        EditText txtTitleA = view.findViewById(R.id.edtTitleA);
        EditText txtContentA = view.findViewById(R.id.edtContentA);
        EditText txtDateA = view.findViewById(R.id.edtDateA);
        EditText txtTypeA = view.findViewById(R.id.edtTypeA);
        Button btnThem = view.findViewById(R.id.btnThem);
        //
        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = txtTitleA.getText().toString();
                String content = txtContentA.getText().toString();
                String date = txtDateA.getText().toString();
                String type = txtTypeA.getText().toString();

                CongViec congViec = new CongViec(title,content,date,type);
                if(congViecDao.add(congViec)){
                    list.clear();
                    list.addAll(congViecDao.selectAll());
                    adapter.notifyDataSetChanged();
                    Toast.makeText(MainActivity.this, "Thêm thành công", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                }
                else {
                    Toast.makeText(MainActivity.this, "Thêm không thành công", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}