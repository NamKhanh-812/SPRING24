package com.example.qlmonan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.qlmonan.Adapter.MonAnAdapter;
import com.example.qlmonan.DAO.MonAnDAO;
import com.example.qlmonan.model.MonAn;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView rcvBaiTap;
    FloatingActionButton fltAdd;
    MonAnDAO monAnDAO;
    MonAnAdapter adapter;
    private ArrayList<MonAn> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rcvBaiTap = findViewById(R.id.rcvBaiTap);
        fltAdd = findViewById(R.id.fltAdd);
        // lấy toàn bộ dữ liệu từ bảng cng việc , add dữ liệu vào list
        monAnDAO = new MonAnDAO(this);
        list = monAnDAO.selectAll();
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        rcvBaiTap.setLayoutManager(layoutManager);
        adapter = new MonAnAdapter(this, list);
        rcvBaiTap.setAdapter(adapter);
        fltAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opendialogThem();
            }
        });
    }

    public void opendialogThem() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.item_add, null);
        builder.setView(view);
        Dialog dialog = builder.create();
        dialog.show();
        EditText edtMa = view.findViewById(R.id.edtMaMonAnA);
        EditText edtTen = view.findViewById(R.id.edtTenMonAnA);
        EditText edtNgayLam = view.findViewById(R.id.edtNgayLamA);
        Button btnAdd = view.findViewById(R.id.btnThem);
        edtTen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder1 = new AlertDialog.Builder(MainActivity.this);
                builder1.setTitle("Chọn tên món");
                String[] ten = {"Mỳ xào chua cay", "Mỳ cay", "Mỳ hải sản", "Cơm tấm", "Bún bò sốt vang", "Bún chả"};
                builder1.setItems(ten, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        edtTen.setText(ten[which]);
                    }
                });
                AlertDialog dialog1 = builder1.create();
                dialog1.show();
            }
        });
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String txtMa = edtMa.getText().toString();
                String txtTen = edtTen.getText().toString();
                String txtNgayLam = edtNgayLam.getText().toString();

                MonAn monAn = new MonAn(txtMa, txtTen, txtNgayLam);


                if (monAnDAO.add(monAn)) {
                    list.clear();
                    list.addAll(monAnDAO.selectAll());
                    adapter.notifyDataSetChanged();
                    Toast.makeText(MainActivity.this, "Thêm thành công", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                }
                else {
                    Toast.makeText(MainActivity.this, "Thêm không thành công", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}