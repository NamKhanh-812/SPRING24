package com.example.qlmonan.DAO;

import static android.content.ContentValues.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.qlmonan.database.DbHelper;
import com.example.qlmonan.model.MonAn;

import java.util.ArrayList;

public class MonAnDAO {
    private final DbHelper dbHelper;

    public MonAnDAO(Context context) {
        dbHelper = new DbHelper(context);
    }

    public ArrayList<MonAn> selectAll() {
        ArrayList<MonAn> list = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery("SELECT * FROM monAn", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                while (!cursor.isAfterLast()) {
                    MonAn monAn = new MonAn();
                    monAn.setId(cursor.getInt(0));
                    monAn.setMaMonAn(cursor.getString(1));
                    monAn.setTenMonAn(cursor.getString(2));
                    monAn.setNgayLam(cursor.getString(3));
                    monAn.setTrangThai(cursor.getInt(4));
                    list.add(monAn);
                    cursor.moveToNext();
                }
            }
        } catch (Exception e) {
            Log.i(TAG, "Lỗi", e);
        }
        return list;
    }

    public boolean add(MonAn monAn) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("MAMON", monAn.getMaMonAn());
        contentValues.put("TENMON", monAn.getTenMonAn());
        contentValues.put("NGAYLAM", monAn.getNgayLam());
        contentValues.put("TRANGTHAI", monAn.getTrangThai());
        long row = db.insert("monAn", null, contentValues);
        return (row > 0);
    }

    public boolean update(MonAn monAn) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("MAMON", monAn.getMaMonAn());
        contentValues.put("TENMON", monAn.getTenMonAn());
        contentValues.put("NGAYLAM", monAn.getNgayLam());
        contentValues.put("TRANGTHAI", monAn.getTrangThai());
        long row = db.update("monAn", contentValues, "ID=?", new String[]{String.valueOf(monAn.getId())});
        return (row > 0);
    }

    public boolean delete(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long row = db.delete("monAn", "ID=?", new String[]{String.valueOf(id)});
        return (row > 0);
    }
}
