package com.example.qlmonan.model;

public class MonAn {
    private String maMonAn, tenMonAn, ngayLam;
    private int id, trangThai;

    public MonAn() {
    }

    public MonAn(String maMonAn, String tenMonAn, String ngayLam, int id, int trangThai) {
        this.maMonAn = maMonAn;
        this.tenMonAn = tenMonAn;
        this.ngayLam = ngayLam;
        this.id = id;
        this.trangThai = trangThai;
    }

    public MonAn(String maMonAn, String tenMonAn, String ngayLam) {
        this.maMonAn = maMonAn;
        this.tenMonAn = tenMonAn;
        this.ngayLam = ngayLam;
    }

    public String getMaMonAn() {
        return maMonAn;
    }

    public void setMaMonAn(String maMonAn) {
        this.maMonAn = maMonAn;
    }

    public String getTenMonAn() {
        return tenMonAn;
    }

    public void setTenMonAn(String tenMonAn) {
        this.tenMonAn = tenMonAn;
    }

    public String getNgayLam() {
        return ngayLam;
    }

    public void setNgayLam(String ngayLam) {
        this.ngayLam = ngayLam;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }
}

