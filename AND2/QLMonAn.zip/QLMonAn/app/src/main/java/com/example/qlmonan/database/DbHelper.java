package com.example.qlmonan.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {
    public static final String Db_name = "QLMA";

    public DbHelper(@Nullable Context context) {
        super(context, Db_name, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String tb_monAn = "CREATE TABLE monAn (ID INTEGER PRIMARY KEY AUTOINCREMENT, MAMON TEXT, TENMON TEXT, NGAYLAM TEXT, TRANGTHAI INTEGER )";
        db.execSQL(tb_monAn);
        String data = "INSERT INTO monAn VALUES(1,'L32','Mì xào chua cay','02/04/2023',0)," +
                "(2,'L92','Mì cay','04/04/2023',1)";
        db.execSQL(data);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion != newVersion) {
            db.execSQL("DROP TABLE IF EXISTS monAn");
            onCreate(db);
        }
    }
}

